$(document).ready(function(){
    $('.btn-login').click(function(){
        var email = $('#email').val();
        var password = $('#password').val();
        if(email === "" && password === ""){
            alert("Vui lòng nhập email và password");
            document.getElementById('email').focus();
        }else if(email === ""){
            alert("Vui lòng nhập email");
            document.getElementById('email').focus();
        }else if(password === ""){
            alert("Vui lòng nhập password");
            document.getElementById('password').focus();
        }
        else{
            
        }
    });

    $().ready(function(){
        $("#login-form").validate({
            rules: {
                 "email": {
                     required: true
                 },
                 "password": {
                     required: true,
                     minlength: 5
                 }
             },
             messages: {
                 "email": {
                     required: "Vui lòng nhập email"
                 },
                 "password": {
                     required: "Vui lòng nhập password",
                     minlength: "Hãy nhập ít nhất 5 ký tự"
                }
            }
        });
    });

    $('.btn-toggle-sidebar').click(function(){
        event.stopPropagation();
        $('.sidebar').css('display','block');
    });

    $(window).click(function(e) 
    {
        var container = $('.sidebar');
    
        // if the target of the click isn't the container nor a descendant of the container
        if (!container.is(e.target) && container.has(e.target).length === 0) 
        {
            container.css('display','none');
        }
    });

    $(".rotate").click(function () {
        $(this).toggleClass("down");
        var in1 = $(this).parent().parent().next();
        in1.collapse('toggle');
    });

    
});

jQuery.validator.addMethod("email", function(value, element){
    return this.optional(element) || /^.+@student.tdtu.edu.vn$/.test(value);
}, "Đuôi mail chỉ được để là @student.tdtu.edu.vn");
